Sprache muss auf Deutsch (Deutschland) eingestellt sein.
Language must be set to Deutsch (Deutschland).